# Deploying

If you would like to run your own instance of this app, see the [docs for deployment](https://probot.github.io/docs/deployment/).

This plugin requires these **Permissions** for the GitHub App:

- Issues - **Read & Write**
  - No necessary events
- Pull requests - **Read & Write**
  - No necessary Events
- Repository Contents - **Read-only**

You'll also need to enable the following **Webhook Events**:
  - **Push**
  - **Pull Requests**
